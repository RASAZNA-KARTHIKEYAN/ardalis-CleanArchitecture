﻿global using Ardalis.SharedKernel;
global using Microsoft.EntityFrameworkCore;
global using NSubstitute;
global using Xunit;
global using Microsoft.Extensions.DependencyInjection;
