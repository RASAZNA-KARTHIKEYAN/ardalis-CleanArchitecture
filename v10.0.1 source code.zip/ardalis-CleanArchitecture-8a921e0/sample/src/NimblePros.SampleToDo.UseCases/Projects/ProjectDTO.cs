﻿namespace NimblePros.SampleToDo.UseCases.Projects;

public record ProjectDTO(int Id, string Name, string Status);
