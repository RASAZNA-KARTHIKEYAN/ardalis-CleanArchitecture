﻿namespace NimblePros.SampleToDo.Web.Projects;

public class ProjectListResponse
{
  public List<ProjectRecord> Projects { get; set; } = new();
}
