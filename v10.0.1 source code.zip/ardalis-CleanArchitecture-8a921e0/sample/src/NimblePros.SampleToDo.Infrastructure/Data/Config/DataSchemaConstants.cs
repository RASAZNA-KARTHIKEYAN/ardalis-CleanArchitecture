﻿namespace NimblePros.SampleToDo.Infrastructure.Data.Config;

public static class DataSchemaConstants
{
  public const int DEFAULT_NAME_LENGTH = 100;
}
